def main():
    print("This is CLI!")
